const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(__dirname+'/game.js','utf8');
const spawn=source.slice(source.indexOf('function pathsSeparate('),source.indexOf('function segmentDistance('));
for(const width of [300,390,580]){
 const state={W:width,H:420,elapsed:30,objects:[],Math};vm.createContext(state);vm.runInContext(spawn,state);
 for(let i=0;i<500;i++){
  state.objects=[];vm.runInContext('spawnWave()',state);assert(state.objects.length>=1&&state.objects.length<=2);
  for(const object of state.objects){assert(object.minX<=object.x&&object.x<=object.maxX);assert(Number.isFinite(object.vy));}
  if(state.objects.length===2){const [a,b]=state.objects;for(let t=0;t<3;t+=1/120){const ay=a.y+a.vy*t+500*t*t,by=b.y+b.vy*t+500*t*t;if(ay>state.H+a.r*1.42||by>state.H+b.r*1.42)continue;const separation=Math.hypot(a.x+a.vx*t-b.x-b.vx*t,ay-by);assert(separation>(a.r+b.r)*Math.SQRT2,'Rotating sprites must remain separate throughout flight');}}
 }
}
const distance=source.slice(source.indexOf('function segmentDistance('),source.indexOf('function cut('));
const state={Math};vm.createContext(state);vm.runInContext(distance,state);assert.equal(vm.runInContext('segmentDistance(5,0,{x:0,y:0},{x:10,y:0})',state),0);assert.equal(vm.runInContext('segmentDistance(5,5,{x:0,y:0},{x:10,y:0})',state),5);assert.equal(vm.runInContext('segmentDistance(3,4,{x:0,y:0},{x:0,y:0})',state),5);
console.log('Passed: 1,500 waves, sprite separation, wave counts, swipe geometry.');
