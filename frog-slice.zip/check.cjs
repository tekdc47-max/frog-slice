const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(__dirname+'/game.js','utf8');
let seed=47,maxObserved=0;const seededMath=Object.create(Math);seededMath.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
const spawn=source.slice(source.indexOf('function difficulty('),source.indexOf('function segmentDistance('));
for(const width of [300,390,580]){
 for(const seconds of [0,15,30,45,59]){
 const state={W:width,H:420,elapsed:seconds,objects:[],Math:seededMath};vm.createContext(state);vm.runInContext(spawn,state);
 for(let i=0;i<100;i++){
  state.objects=[];vm.runInContext('spawnWave()',state);assert(state.objects.length>=1&&state.objects.length<=Math.min(5,2+Math.floor(seconds/15)));
  maxObserved=Math.max(maxObserved,state.objects.length);
  for(const object of state.objects){assert(object.minX<=object.x&&object.x<=object.maxX);assert(Number.isFinite(object.vy));}
  for(let aIndex=0;aIndex<state.objects.length;aIndex++)for(let bIndex=aIndex+1;bIndex<state.objects.length;bIndex++){const a=state.objects[aIndex],b=state.objects[bIndex];for(let t=0;t<3;t+=1/120){if(t<a.delay||t<b.delay)continue;const at=t-a.delay,bt=t-b.delay;const ay=a.y+a.vy*at+a.gravity*.5*at*at,by=b.y+b.vy*bt+b.gravity*.5*bt*bt;if(ay>state.H+a.r*1.42||by>state.H+b.r*1.42)continue;const ax=Math.max(a.minX,Math.min(a.maxX,a.x+a.vx*at)),bx=Math.max(b.minX,Math.min(b.maxX,b.x+b.vx*bt));const separation=Math.hypot(ax-bx,ay-by);assert(separation>(a.r+b.r)*Math.SQRT2,'Rotating sprites must remain separate throughout flight');}}
 }
 }
}
const distance=source.slice(source.indexOf('function segmentDistance('),source.indexOf('function cut('));
const state={Math};vm.createContext(state);vm.runInContext(distance,state);assert.equal(vm.runInContext('segmentDistance(5,0,{x:0,y:0},{x:10,y:0})',state),0);assert.equal(vm.runInContext('segmentDistance(5,5,{x:0,y:0},{x:10,y:0})',state),5);assert.equal(vm.runInContext('segmentDistance(3,4,{x:0,y:0},{x:0,y:0})',state),5);
vm.runInContext(spawn,state);const early=vm.runInContext('difficulty(0)',state),late=vm.runInContext('difficulty(59)',state);assert(late.gravity>early.gravity);assert(late.interval<early.interval);assert(late.highChance>early.highChance);assert(late.pairChance>early.pairChance);assert.equal(late.stage,4);
assert.equal(early.maxTargets,2);assert.equal(late.maxTargets,5);
assert.equal(maxObserved,5,'Later waves must be able to actually spawn five targets');
const hit=(obj,from,to)=>{state.obj=obj;state.from=from;state.to=to;return vm.runInContext('swipeHits(obj,from,to)',state)};
assert(hit({x:100,y:100,r:24,bomb:false},{x:0,y:125,time:0},{x:200,y:125,time:50}),'Horizontal swipe across visible outer edge');
assert(hit({x:100,y:100,r:24,bomb:false},{x:0,y:100,time:0},{x:200,y:100,time:450}),'Sparse mouse events must retain the horizontal segment');
assert(hit({x:110,y:130,r:24,bomb:false,pointerX:100,pointerY:70,pointerTime:0},{x:40,y:100,time:0},{x:180,y:100,time:100}),'Target motion during a swipe must be considered');
assert(!hit({x:100,y:100,r:24,bomb:false},{x:0,y:150,time:0},{x:200,y:150,time:50}),'Distant swipe must not hit');
assert(!hit({x:100,y:100,r:24,bomb:true},{x:0,y:125,time:0},{x:200,y:125,time:50}),'Do not expand bomb hit area');
const pointerCode=source.slice(source.indexOf('function pointer('),source.indexOf('function drawWeapon('));const pointerState={playing:true,paused:false,elapsed:1,lastPointer:{x:0,y:0,time:0},weapon:null,trail:[],objects:[{x:50,y:50,r:10,bomb:false}],canvas:{getBoundingClientRect:()=>({left:10,top:20})},cut:obj=>{obj.cut=true},Math};vm.createContext(pointerState);vm.runInContext(distance+pointerCode,pointerState);pointerState.event={type:'pointermove',pointerType:'mouse',clientX:110,clientY:20,timeStamp:100,preventDefault(){},getCoalescedEvents(){return [{clientX:60,clientY:70,timeStamp:50}]}};vm.runInContext('pointer(event)',pointerState);assert(pointerState.objects[0].cut,'Coalesced movement through a target must hit even if endpoints miss');
console.log('Passed: 1,500 waves across 5 difficulty stages, trajectory separation, horizontal/sparse/moving-target/coalesced swipes, difficulty progression.');

